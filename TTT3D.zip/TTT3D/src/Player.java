import java.util.*;

public class Player {
    /**
     * Performs a move
     *
     * @param gameState
     *            the current state of the board
     * @param deadline
     *            time before which we must have returned
     * @return the next state the board is in after our move
     */
	private int thisPlayer;
	private HashMap<Integer, Integer> hashmap = new HashMap<Integer, Integer>();
    private int[][][] hashingMatrix = {{{1,2,2,1},{2,4,4,2},{2,4,4,2},{1,2,2,1}},{{2,4,4,2},{4,8,8,4},{4,8,8,4},{2,4,4,2}},{{2,4,4,2},{4,8,8,4},{4,8,8,4},{2,4,4,2}},{{1,2,2,1},{2,4,4,2},{2,4,4,2},{1,2,2,1}}};
	
    public GameState play(final GameState gameState, final Deadline deadline) {
        Vector<GameState> nextStates = new Vector<GameState>();
        gameState.findPossibleMoves(nextStates);
        

        if (nextStates.size() == 0) {
            // Must play "pass" move if there are no other moves possible.
            return new GameState(gameState, new Move());
        }

        /**
         * Here you should write your algorithms to get the best next move, i.e.
         * the best next state. This skeleton returns a random move instead.
         */
        
        //Random random = new Random();
        int depth = 3;
        thisPlayer = gameState.getNextPlayer();
        Pair result = alpha_beta(gameState, thisPlayer,depth,Integer.MIN_VALUE,Integer.MAX_VALUE);
        return nextStates.elementAt(result.index);
    }
    public Pair alpha_beta (GameState gameState, int player, int depth, int alpha, int beta){
        int v=0;
        Pair result = new Pair (-1, -1);
        Pair aux;
        GameState state;
        int hash;
        if (gameState.isEOG() || depth == 0){
            return new Pair(-1,utility(gameState,player));
        }else{
            Vector<GameState> nextStates = new Vector<GameState>();
            gameState.findPossibleMoves(nextStates);
            boolean no_prune = true;
            if(player == thisPlayer){
                v = Integer.MIN_VALUE;
                for(int i = 0; i<nextStates.size() && no_prune; i++){
                    state = nextStates.get(i);
                   /* hash = computeHash(state);
                    
                    if(hashmap.containsKey(hash)){
                        aux = new Pair(i,hashmap.get(hash));
                        //System.err.println("hash:");
                        //System.err.println(hash);
                        //System.err.println("value:");
                        //System.err.println(aux.value);
                    }else{*/
                        aux = alpha_beta(state, state.getNextPlayer(), depth-1, alpha, beta);
                        //hashmap.put(i, aux.value);
                    //}
                    if(v<aux.value){
                        v=aux.value;
                        result = new Pair(i, v); 
                    }
                    alpha = max(alpha, v);
                    if (beta<=alpha){
                        no_prune = false;
                    }
                }
            }else{
                v = Integer.MAX_VALUE;
                for(int i = 0; i<nextStates.size(); i++){
                    state = nextStates.get(i);
                    /*hash = computeHash(state);
                    if(hashmap.containsKey(hash)){
                        aux = new Pair(i,hashmap.get(hash));
                    }else{*/
                        aux = alpha_beta(state, state.getNextPlayer(), depth-1, alpha, beta);
                    /*    hashmap.put(i, aux.value);
                    }*/
                    if(v>aux.value){
                    	v=aux.value;
                    	result = new Pair(i, v);
                    }
                    beta = min(beta, v);
                    if(alpha<=beta){
                        no_prune = false;
                    }
                }
            }
            return result;
            
        }
    }
    
    public int computeHash (GameState state){
        int hash = 0;
        /*for(int i = 0; i<state.BOARD_SIZE; i++){
            for(int j = 0; j<state.BOARD_SIZE; j++){
                for(int k = 0; k<state.BOARD_SIZE; k++){
                    hash += state.at(i, j, k)*hashingMatrix[i][j][k];
                }
            }
        }*/
        
        for(int i = 0; i<state.CELL_COUNT; i++){
            
                    hash += state.at(i)*Math.pow(2,i);
           
        }
        
        return hash;
    }

    
    public int utility(GameState gameState, int player){
        int score = 0;
       
        //evaluate_rows
        for (int layer= 0; layer < 3; layer++){
	        for(int i = 0; i<gameState.BOARD_SIZE; i++){
	            score += evaluate_row(i,gameState, layer);
	            score += evaluate_col(i,gameState,layer);
	        }
	        //evaluate diagonals
	        score += evaluate_diagonal1(gameState,layer);
	        score += evaluate_diagonal2(gameState,layer);
    	}
        //evaluate big lines (lines between layers)
        for (int row=0; row < 3; row++){
        	for (int col=0; col<3; col++){
        		score += evaluate_bigLine(row, col,gameState);
        	}
        }
        //evaluate big diagonals
        evaluate_bigDiagonal1(gameState);
        evaluate_bigDiagonal2(gameState);
        evaluate_bigDiagonal3(gameState);
        evaluate_bigDiagonal4(gameState);
        
        if(gameState.isXWin()&&player == Constants.CELL_X){
            score += 10000;
        }else if(gameState.isOWin()&&player == Constants.CELL_O){
            score += -10000;
        
        }
        
        
        return score;
    }
    
    public int evaluate_diagonal1(GameState gameState, int layer){
        int score = 0;
        if(gameState.at(0, 0, layer)==Constants.CELL_X){
                score=1;
            }else if(gameState.at(0, 0, layer)==Constants.CELL_O){
                score=-1;
            }
            
            if(gameState.at(1, 1, layer)==Constants.CELL_X){
                if(score == 1){
                    score = 10;
                }else if (score == -1){
                    return 0;
                }else{
                    score = 1;
                }
            }else if(gameState.at(1, 1, layer)==Constants.CELL_O){
                if(score == -1){
                    score = -10;
                }else if (score == 1){
                    return 0;
                }else{
                    score = -1;
                }
            }
            
            if(gameState.at(2, 2, layer)==Constants.CELL_X){
                if(score > 0){
                    score*=10;
                }else if (score == -1){
                    return 0;
                }else{
                    score = 1;
                }
            }else if(gameState.at(2, 2, layer)==Constants.CELL_O){
                if(score < 0){
                    score*=10;
                }else if (score == 1){
                    return 0;
                }else{
                    score = -1;
                }
            }
            
            if(gameState.at(3, 3, layer)==Constants.CELL_X){
                if(score > 0){
                    score*=10;
                }else if (score == -1){
                    return 0;
                }else{
                    score = 1;
                }
            }else if(gameState.at(3, 3, layer)==Constants.CELL_O){
                if(score < 0){
                    score*=10;
                }else if (score == 1){
                    return 0;
                }else{
                    score = -1;
                }
            }
        return score;
    }
    
    
    public int evaluate_diagonal2(GameState gameState, int layer){
        int score = 0;
        if(gameState.at(0, 3, layer)==Constants.CELL_X){
            score=1;
        }else if(gameState.at(0, 3, layer)==Constants.CELL_O){
            score=-1;
        }

        if(gameState.at(1, 2, layer)==Constants.CELL_X){
            if(score == 1){
                score = 10;
            }else if (score == -1){
                return 0;
            }else{
                score = 1;
            }
        }else if(gameState.at(1, 2, layer)==Constants.CELL_O){
            if(score == -1){
                score = -10;
            }else if (score == 1){
                return 0;
            }else{
                score = -1;
            }
        }

        if(gameState.at(2, 1, layer)==Constants.CELL_X){
            if(score > 0){
                score*=10;
            }else if (score == -1){
                return 0;
            }else{
                score = 1;
            }
        }else if(gameState.at(2, 1, layer)==Constants.CELL_O){
            if(score < 0){
                score*=10;
            }else if (score == 1){
                return 0;
            }else{
                score = -1;
            }
        }

        if(gameState.at(3, 0, layer)==Constants.CELL_X){
            if(score > 0){
                score*=10;
            }else if (score == -1){
                return 0;
            }else{
                score = 1;
            }
        }else if(gameState.at(3, 0, layer)==Constants.CELL_O){
            if(score < 0){
                score*=10;
            }else if (score == 1){
                return 0;
            }else{
                score = -1;
            }
        }
        return score;
    }
    
    
    public int evaluate_row(int row, GameState gameState, int layer){
        int score = 0;
        if(gameState.at(row, 0, layer)==Constants.CELL_X){
            score=1;
        }else if(gameState.at(row, 0,layer)==Constants.CELL_O){
            score=-1;
        }

        if(gameState.at(row, 1,layer)==Constants.CELL_X){
            if(score == 1){
                score = 10;
            }else if (score == -1){
                return 0;
            }else{
                score = 1;
            }
        }else if(gameState.at(row, 1,layer)==Constants.CELL_O){
            if(score == -1){
                score = -10;
            }else if (score == 1){
                return 0;
            }else{
                score = -1;
            }
        }

        if(gameState.at(row, 2,layer)==Constants.CELL_X){
            if(score > 0){
                score*=10;
            }else if (score == -1){
                return 0;
            }else{
                score = 1;
            }
        }else if(gameState.at(row, 2,layer)==Constants.CELL_O){
            if(score < 0){
                score*=10;
            }else if (score == 1){
                return 0;
            }else{
                score = -1;
            }
        }

        if(gameState.at(row, 3,layer)==Constants.CELL_X){
            if(score > 0){
                score*=10;
            }else if (score == -1){
                return 0;
            }else{
                score = 1;
            }
        }else if(gameState.at(row, 3,layer)==Constants.CELL_O){
            if(score < 0){
                score*=10;
            }else if (score == 1){
                return 0;
            }else{
                score = -1;
            }
        }
        return score;
    }
    
    
    public int evaluate_col(int col, GameState gameState, int layer){
        int score = 0;
        if(gameState.at(0, col,layer)==Constants.CELL_X){
            score=1;
        }else if(gameState.at(0, col,layer)==Constants.CELL_O){
            score=-1;
        }

        if(gameState.at(1, col,layer)==Constants.CELL_X){
            if(score == 1){
                score = 10;
            }else if (score == -1){
                return 0;
            }else{
                score = 1;
            }
        }else if(gameState.at(1, col,layer)==Constants.CELL_O){
            if(score == -1){
                score = -10;
            }else if (score == 1){
                return 0;
            }else{
                score = -1;
            }
        }

        if(gameState.at(2, col,layer)==Constants.CELL_X){
            if(score > 0){
                score*=10;
            }else if (score == -1){
                return 0;
            }else{
                score = 1;
            }
        }else if(gameState.at(2,col,layer)==Constants.CELL_O){
            if(score < 0){
                score*=10;
            }else if (score == 1){
                return 0;
            }else{
                score = -1;
            }
        }

        if(gameState.at(3, col,layer)==Constants.CELL_X){
            if(score > 0){
                score*=10;
            }else if (score == -1){
                return 0;
            }else{
                score = 1;
            }
        }else if(gameState.at(3, col,layer)==Constants.CELL_O){
            if(score < 0){
                score*=10;
            }else if (score == 1){
                return 0;
            }else{
                score = -1;
            }
        }
        return score;
    }
    
    public int evaluate_bigLine(int row, int col, GameState gameState){
        int score = 0;
        
        if(gameState.at(row, col, 0)==Constants.CELL_X){
            score=1;
        }else if(gameState.at(row, col,0)==Constants.CELL_O){
            score=-1;
        }

        if(gameState.at(row, col,1)==Constants.CELL_X){
            if(score == 1){
                score = 10;
            }else if (score == -1){
                return 0;
            }else{
                score = 1;
            }
        }else if(gameState.at(row, col,1)==Constants.CELL_O){
            if(score == -1){
                score = -10;
            }else if (score == 1){
                return 0;
            }else{
                score = -1;
            }
        }

        if(gameState.at(row, col,2)==Constants.CELL_X){
            if(score > 0){
                score*=10;
            }else if (score == -1){
                return 0;
            }else{
                score = 1;
            }
        }else if(gameState.at(row, col,2)==Constants.CELL_O){
            if(score < 0){
                score*=10;
            }else if (score == 1){
                return 0;
            }else{
                score = -1;
            }
        }

        if(gameState.at(row, col,3)==Constants.CELL_X){
            if(score > 0){
                score*=10;
            }else if (score == -1){
                return 0;
            }else{
                score = 1;
            }
        }else if(gameState.at(row, col,3)==Constants.CELL_O){
            if(score < 0){
                score*=10;
            }else if (score == 1){
                return 0;
            }else{
                score = -1;
            }
        }
        return score;
    }
    
    public int evaluate_bigDiagonal1(GameState gameState){
        int score = 0;
        if(gameState.at(0, 3, 3)==Constants.CELL_X){
            score=1;
        }else if(gameState.at(0, 3, 3)==Constants.CELL_O){
            score=-1;
        }

        if(gameState.at(1, 2, 2)==Constants.CELL_X){
            if(score == 1){
                score = 10;
            }else if (score == -1){
                return 0;
            }else{
                score = 1;
            }
        }else if(gameState.at(1, 2, 2)==Constants.CELL_O){
            if(score == -1){
                score = -10;
            }else if (score == 1){
                return 0;
            }else{
                score = -1;
            }
        }

        if(gameState.at(2, 1, 1)==Constants.CELL_X){
            if(score > 0){
                score*=10;
            }else if (score == -1){
                return 0;
            }else{
                score = 1;
            }
        }else if(gameState.at(2, 1, 1)==Constants.CELL_O){
            if(score < 0){
                score*=10;
            }else if (score == 1){
                return 0;
            }else{
                score = -1;
            }
        }

        if(gameState.at(3, 0, 0)==Constants.CELL_X){
            if(score > 0){
                score*=10;
            }else if (score == -1){
                return 0;
            }else{
                score = 1;
            }
        }else if(gameState.at(3, 0, 0)==Constants.CELL_O){
            if(score < 0){
                score*=10;
            }else if (score == 1){
                return 0;
            }else{
                score = -1;
            }
        }
        return score;
    }
    
    public int evaluate_bigDiagonal2(GameState gameState){
        int score = 0;
        if(gameState.at(3, 3, 0)==Constants.CELL_X){
            score=1;
        }else if(gameState.at(3, 3, 0)==Constants.CELL_O){
            score=-1;
        }

        if(gameState.at(2, 2, 1)==Constants.CELL_X){
            if(score == 1){
                score = 10;
            }else if (score == -1){
                return 0;
            }else{
                score = 1;
            }
        }else if(gameState.at(2, 2, 1)==Constants.CELL_O){
            if(score == -1){
                score = -10;
            }else if (score == 1){
                return 0;
            }else{
                score = -1;
            }
        }

        if(gameState.at(1, 1, 2)==Constants.CELL_X){
            if(score > 0){
                score*=10;
            }else if (score == -1){
                return 0;
            }else{
                score = 1;
            }
        }else if(gameState.at(1, 1, 2)==Constants.CELL_O){
            if(score < 0){
                score*=10;
            }else if (score == 1){
                return 0;
            }else{
                score = -1;
            }
        }

        if(gameState.at(0, 0, 3)==Constants.CELL_X){
            if(score > 0){
                score*=10;
            }else if (score == -1){
                return 0;
            }else{
                score = 1;
            }
        }else if(gameState.at(0, 0, 3)==Constants.CELL_O){
            if(score < 0){
                score*=10;
            }else if (score == 1){
                return 0;
            }else{
                score = -1;
            }
        }
        return score;
    }
    
    public int evaluate_bigDiagonal3(GameState gameState){
        int score = 0;
        if(gameState.at(3, 0, 0)==Constants.CELL_X){
            score=1;
        }else if(gameState.at(3, 0, 0)==Constants.CELL_O){
            score=-1;
        }

        if(gameState.at(2, 1, 1)==Constants.CELL_X){
            if(score == 1){
                score = 10;
            }else if (score == -1){
                return 0;
            }else{
                score = 1;
            }
        }else if(gameState.at(2, 1, 1)==Constants.CELL_O){
            if(score == -1){
                score = -10;
            }else if (score == 1){
                return 0;
            }else{
                score = -1;
            }
        }

        if(gameState.at(1, 2, 2)==Constants.CELL_X){
            if(score > 0){
                score*=10;
            }else if (score == -1){
                return 0;
            }else{
                score = 1;
            }
        }else if(gameState.at(1, 2, 2)==Constants.CELL_O){
            if(score < 0){
                score*=10;
            }else if (score == 1){
                return 0;
            }else{
                score = -1;
            }
        }

        if(gameState.at(0, 3, 3)==Constants.CELL_X){
            if(score > 0){
                score*=10;
            }else if (score == -1){
                return 0;
            }else{
                score = 1;
            }
        }else if(gameState.at(0, 3, 3)==Constants.CELL_O){
            if(score < 0){
                score*=10;
            }else if (score == 1){
                return 0;
            }else{
                score = -1;
            }
        }
        return score;
    }
    
    public int evaluate_bigDiagonal4(GameState gameState){
        int score = 0;
        if(gameState.at(0, 0, 0)==Constants.CELL_X){
            score=1;
        }else if(gameState.at(0, 0, 0)==Constants.CELL_O){
            score=-1;
        }

        if(gameState.at(1, 1, 1)==Constants.CELL_X){
            if(score == 1){
                score = 10;
            }else if (score == -1){
                return 0;
            }else{
                score = 1;
            }
        }else if(gameState.at(1, 1, 1)==Constants.CELL_O){
            if(score == -1){
                score = -10;
            }else if (score == 1){
                return 0;
            }else{
                score = -1;
            }
        }

        if(gameState.at(2, 2, 2)==Constants.CELL_X){
            if(score > 0){
                score*=10;
            }else if (score == -1){
                return 0;
            }else{
                score = 1;
            }
        }else if(gameState.at(2, 2, 2)==Constants.CELL_O){
            if(score < 0){
                score*=10;
            }else if (score == 1){
                return 0;
            }else{
                score = -1;
            }
        }

        if(gameState.at(3, 3, 3)==Constants.CELL_X){
            if(score > 0){
                score*=10;
            }else if (score == -1){
                return 0;
            }else{
                score = 1;
            }
        }else if(gameState.at(3, 3, 3)==Constants.CELL_O){
            if(score < 0){
                score*=10;
            }else if (score == 1){
                return 0;
            }else{
                score = -1;
            }
        }
        return score;
    }
    
   
    public int max(int a, int b){
        if(a>b){
            return a;
        }else{
            return b;
        }
    }
    public int min(int a, int b){
        if(a<b){
            return a;
        }else{
            return b;
        }
    }
}
