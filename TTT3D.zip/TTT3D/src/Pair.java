
public class Pair {

    
    public int index;
    public int value;
    
    public Pair(int index, int value) {
        this.index = index;
        this.value = value;
    }
    
	
}